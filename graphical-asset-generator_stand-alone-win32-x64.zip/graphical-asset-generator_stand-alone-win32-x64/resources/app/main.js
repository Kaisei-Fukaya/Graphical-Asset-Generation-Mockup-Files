const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
app.isPackaged || require('electron-reloader')(module);

const createWindow = () => {
    const win = new BrowserWindow({
        show: false,
        width: 800,
        height: 600,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
/*             nodeIntegration: true,
            contextIsolation: false, */
        },
    });
    win.maximize();
    win.show();
    win.setMenuBarVisibility(false);
    ipcMain.handle('ping', () => 'pong');
    win.loadFile('index.html');
};

app.whenReady().then(() => {
    createWindow();

    ipcMain.handle('dialog', (event, method, params) => {       
        return dialog[method](params);
    });

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
          createWindow();
        }
    });
});

app.on("window-all-closed", () => {
    if(process.platform !== 'darwin') {
        app.quit();
    };
});

/* app.on('ready', () => {
    mainWindow = new BrowserWindow({
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
        }
    });
}); */

class generatorData{
    selectedType= "";
    selectedFormat= "";
    selectedInput= "";
    selectedTech= "";
}
