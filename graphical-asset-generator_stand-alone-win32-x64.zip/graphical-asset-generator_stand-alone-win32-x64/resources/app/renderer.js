let nb1 = document.getElementById("next-button");
let currentPage = window.location.pathname.substring(location.pathname.lastIndexOf("/") + 1);
if(nb1 !== null){
        switch(currentPage){
            case "index.html":
                if(nb1 !== null){
                    nb1.onclick = () => window.location.href='./page_1.html';
                }
                break;
            case "page_1.html":
                if(nb1 !== null){
                    nb1.onclick = () => window.location.href='./page_2.html';
                    nb1.disabled = true;
                }
                break;
            case "page_2.html":
                if(nb1 !== null){
                    nb1.onclick = () => window.location.href='./page_3.html';
                    nb1.disabled = true;
                }
                InitBreadcrumbs(
                    document.getElementsByClassName('bc-type')[0], 
                    undefined,
                    undefined
                    );
                break;
            case "page_3.html":
                if(nb1 !== null){
                    nb1.onclick = () => window.location.href='./page_4.html';
                    nb1.disabled = true;
                }
                InitBreadcrumbs(
                    document.getElementsByClassName('bc-type')[0], 
                    document.getElementsByClassName('bc-format')[0],
                    undefined
                    );
                break;
            case "page_4.html":
                if(nb1 !== null){
                    nb1.onclick = () => window.location.href='./index.html';
                }
                InitBreadcrumbs(
                    document.getElementsByClassName('bc-type')[0], 
                    document.getElementsByClassName('bc-format')[0],
                    document.getElementsByClassName('bc-input-tech')[0]
                    );
                break;
        }
};

let optionListContainer = document.getElementsByClassName("option-list-container");
let optionListA = document.getElementsByClassName("OLI-set-a");
let optionListB = document.getElementsByClassName("OLI-set-b");
let optionListValuesA = new Array(0);
let optionListValuesB = new Array(0);
if(optionListA !== null){
    Array.from(optionListA).forEach(element => {
        switch(window.location.pathname.substring(location.pathname.lastIndexOf("/") + 1)){
            case "page_1.html":
                element.onclick = function() {SetSelectedOptionA(element.innerHTML, 0)};
                break;
            case "page_2.html":
                element.onclick = function() {SetSelectedOptionA(element.innerHTML, 1)};
                break;
            case "page_3.html":
                element.onclick = function() {SetSelectedOptionA(element.innerHTML, 2)};
                break;
        }

        optionListValuesA.push(element.innerHTML);
    });
}

if(optionListB !== null){
    Array.from(optionListB).forEach(element => {
        switch(window.location.pathname.substring(location.pathname.lastIndexOf("/") + 1)){
            case "page_3.html":
                element.onclick = function() {SetSelectedOptionB(element.innerHTML, 2)};
                break;
        }

        optionListValuesB.push(element.innerHTML);
    });
}

function SetSelectedOptionA(value, valToSet){
    Array.from(optionListA).forEach(element => {
        element.setAttribute('state', 'false');
    });
    let item = optionListA[optionListValuesA.indexOf(value)];
    item.setAttribute('state', 'true');
    switch(valToSet){
        case 0:
            window.sessionStorage.setItem("currentDataType", item.getElementsByTagName('p')[0].innerHTML);
            break;
        case 1:
            window.sessionStorage.setItem("currentDataFormat", item.getElementsByTagName('p')[0].innerHTML);
            break;
        case 2:
            window.sessionStorage.setItem("currentDataInput", item.getElementsByTagName('p')[0].innerHTML);
            break;
    }
    dispatchEvent(OnSetSelectedOption);
    console.log(`type ${window.sessionStorage.getItem("currentDataType")}   format ${window.sessionStorage.getItem("currentDataFormat")}  input ${window.sessionStorage.getItem("currentDataInput")} tech ${window.sessionStorage.getItem("currentDataTech")}}`);
}

function SetSelectedOptionB(value, valToSet){
    Array.from(optionListB).forEach(element => {
        element.setAttribute('state', 'false');
    });
    let item = optionListB[optionListValuesB.indexOf(value)];
    item.setAttribute('state', 'true');
    switch(valToSet){
        case 0:
            break;
        case 1:
            break;
        case 2:
            window.sessionStorage.setItem("currentDataTech", item.getElementsByTagName('p')[0].innerHTML);
            break;
    }
    nb1.disabled = false;
    dispatchEvent(OnSetSelectedOption2);
    console.log(`type ${window.sessionStorage.getItem("currentDataType")}   format ${window.sessionStorage.getItem("currentDataFormat")}  input ${window.sessionStorage.getItem("currentDataInput")} tech ${window.sessionStorage.getItem("currentDataTech")}}`);
}


let OnSetSelectedOption = new Event("setSelectedOption");
let OnSetSelectedOption2 = new Event("setSelectedOption2");

let dimensionToggle = document.getElementById("dimension-toggle");
let dim3D = document.getElementById("dim-3D");
let dim2D = document.getElementById("dim-2D");
if(dimensionToggle !== null){
    dimensionToggle.onclick = function() {UpdateVisibleFormatList(this)};
    UpdateVisibleFormatList(dimensionToggle);
}

function UpdateVisibleFormatList(toggle){
    if(toggle.checked == true){
        dim3D.style.display = "none";
        dim2D.style.display = "initial";
        return;
    }
    dim2D.style.display = "none";
    dim3D.style.display = "initial";
}

function InitBreadcrumbs(bcType, bcFormat, bcInputTech){
    if(bcType !== undefined){
        bcType.getElementsByTagName('p')[0].innerHTML = "Output: " + window.sessionStorage.getItem("currentDataType");
        bcType.onclick = () => {
            window.sessionStorage.setItem("currentDataFormat", undefined);
            window.sessionStorage.setItem("currentDataInput", undefined);
            window.sessionStorage.setItem("currentDataTech", undefined);
            window.location.href='./page_1.html';
        }
    }

    if(bcFormat !== undefined){
        bcFormat.getElementsByTagName('p')[0].innerHTML = "Format: " + window.sessionStorage.getItem("currentDataFormat");
        bcFormat.onclick = () => {
            window.sessionStorage.setItem("currentDataInput", undefined);
            window.sessionStorage.setItem("currentDataTech", undefined);
            window.location.href='./page_2.html';
        }
    }

    if(bcInputTech !== undefined){
        let bcInputTechText = bcInputTech.getElementsByTagName('p')[0];
        bcInputTechText.innerHTML = "Input: " + window.sessionStorage.getItem("currentDataInput");
        let cTech = window.sessionStorage.getItem("currentDataTech");
        if(cTech != undefined && cTech != "undefined"){
            bcInputTechText.innerHTML += "</br>Technique: " + cTech;
        }
        bcInputTech.onclick = () => {
            window.location.href='./page_3.html';
        }
    }
}

if(currentPage == "index.html"){
    let saveLoadContainer = document.getElementById("save-load-container");
    if(saveLoadContainer !== null){
        LoadData(saveLoadContainer);
    }
}

if(currentPage == "page_1.html"){
    addEventListener('setSelectedOption', (e) => {
        let value = window.sessionStorage.getItem("currentDataType");
        if(value == "Building" ||
            value == "Tree" ||
            value == "Cloud" ||
            value == "Furniture" ||
            value == "Vehicle"
        )
        {
            window.sessionStorage.setItem("dataTypeDimension", "3D");
        }
        else{
            window.sessionStorage.setItem("dataTypeDimension", "2D");
        }
        nb1.disabled = false;
    }, false);
}

if(currentPage == "page_2.html"){
    let chosenDimension = window.sessionStorage.getItem("dataTypeDimension");
    if(chosenDimension == "3D"){
        let group2D = document.getElementById("dim-2D");
        group2D.style.display = "none";
    }
    else if(chosenDimension == "2D"){
        let group3D = document.getElementById("dim-3D");
        group3D.style.display = "none";
    }

    addEventListener('setSelectedOption', (e) => {
        nb1.disabled = false;
    }, false);
}

if(currentPage == "page_3.html"){
    let allTextOpts = Array.from(document.getElementsByClassName("opt-text"));
    let allImageOpts = Array.from(document.getElementsByClassName("opt-image"));
    let allModelOpts = Array.from(document.getElementsByClassName("opt-model"));

    let chosenDimension = window.sessionStorage.getItem("dataTypeDimension");
    let toHide = Array(0);
    if(chosenDimension == "2D"){
        toHide = allModelOpts;
        Array.from(allImageOpts).forEach(element =>{
            if(element.getElementsByTagName('p')[0].innerHTML == "Multi-view Images"){
                toHide.push(element);
            }
        });
    }
    if(chosenDimension == "3D"){
        toHide = allTextOpts;
    }

    Array.from(toHide).forEach(element => {
        element.style.display = "none";
    });

    let techList = document.getElementById("tech-olc");
    let showTechList = false;

    function setTechListVisibility(){
        if(showTechList == false){
            techList.style.display = "none";
            return;
        }
        techList.style.display = "flex";
        setTechListOptions();
    }

    function setTechListOptions(){
        Array.from(optionListB).forEach(element => {
            element.style.display = "none";
            element.setAttribute('state', 'false');
        });


        switch(window.sessionStorage.getItem("dataTypeDimension")){
            case "3D":
                switch(window.sessionStorage.getItem("currentDataInput")){
                    case "Mesh":
                        Array.from(document.getElementsByClassName("3d-allowed-mesh")).forEach(element =>{
                            element.style.display = "flex";
                        });
                        break;
                    case "Point-Cloud":
                        Array.from(document.getElementsByClassName("3d-allowed-pc")).forEach(element =>{
                            element.style.display = "flex";
                        });
                        break;
                    case "Image":
                        Array.from(document.getElementsByClassName("3d-allowed-bitmap")).forEach(element =>{
                            element.style.display = "flex";
                        });
                        break;
                    case "Multi-view Images":
                        Array.from(document.getElementsByClassName("3d-allowed-bitmap")).forEach(element =>{
                            element.style.display = "flex";
                        });
                        break;
                }
                break;
            case "2D":
                switch(window.sessionStorage.getItem("currentDataInput")){
                    case "Text":
                        break;
                    case "Image":
                        Array.from(document.getElementsByClassName("2d-allowed-bitmap")).forEach(element =>{
                            element.style.display = "flex";
                        });
                        break;
                }
                break;
        }
    }

    setTechListVisibility();

    addEventListener('setSelectedOption', (e) => {
        showTechList = true;
        switch(window.sessionStorage.getItem("currentDataInput")){
            case "None":
                showTechList = false;
                nb1.disabled = false;
                break;
            case "Text":
                showTechList = false;
                nb1.disabled = false;
                break;
            default:
                nb1.disabled = true;
                break;
        }
        window.sessionStorage.setItem("currentDataTech", undefined);
        setTechListVisibility();
    }, false);
}

if(currentPage == "page_4.html"){
    let setInputFilePathButton = document.getElementById("set-input-path-button");
    let inputFilePath = document.getElementById("input-path");
    let inputPath = window.sessionStorage.getItem("currentInputDir");
    if(inputPath != undefined){
        inputFilePath.innerHTML = inputPath;
    }
    if(setInputFilePathButton !== null){
        setInputFilePathButton.onclick = () => {data.openFilePicker('showOpenDialog', {properties: ['openDirectory', 'multiSelections']}).then(result => inputFilePath.innerHTML = `${result.filePaths[0]} <span>${result.filePaths[0]}</span`)};
    }

    let setOutputFilePathButton = document.getElementById("set-output-path-button");
    let outputFilePath = document.getElementById("output-path");
    let outputPath = window.sessionStorage.getItem("currentOutputDir");
    if(outputPath != undefined){
        outputFilePath.innerHTML = outputPath;
    }
    if(setOutputFilePathButton !== null){
        setOutputFilePathButton.onclick = () => {data.openFilePicker('showOpenDialog', {properties: ['openDirectory', 'multiSelections']}).then(result => outputFilePath.innerHTML = `${result.filePaths[0]} <span>${result.filePaths[0]}</span`)};
    }

    let inputGroup = document.getElementById("input-group");
    if(inputGroup !== null){
        if(window.sessionStorage.getItem("currentDataInput") === "None"){
            inputGroup.style.display = "none";
        }
    }

    let timePerAsset = 3;
    let baseTime = 5;

    let estTimeElement = document.getElementById("estimated-time");
    let nOfAssetsInput = document.getElementById("n-of-assets");
    let nGen = window.sessionStorage.getItem("currentNGen");
    if(nOfAssetsInput !== null){
        nOfAssetsInput.addEventListener('input', (event) => {
            estTimeElement.innerHTML = ((timePerAsset*event.target.value)+baseTime)+"m";
        })
    }
    if(nGen != undefined){
        nOfAssetsInput.value = nGen;
        var e = new Event('input');
        nOfAssetsInput.dispatchEvent(e);
    }

    let saveButton = document.getElementById("save-button");
    if(saveButton !== null){
        saveButton.onclick = () => {
            SaveData();
            saveButton.disabled = true;
        };
    }

    function SaveData(){
        let cfgs = window.localStorage.getItem("savedConfigs");
        let cfgsLoaded;
        if(cfgs == undefined){
            cfgsLoaded = Array(0);
        }
        else{
            cfgsLoaded = JSON.parse(cfgs);
        }

        let newConfig = {
            type: window.sessionStorage.getItem("currentDataType"),
            format: window.sessionStorage.getItem("currentDataFormat"),
            input: window.sessionStorage.getItem("currentDataInput"),
            tech: window.sessionStorage.getItem("currentDataTech"),
            typeDim: window.sessionStorage.getItem("dataTypeDimension"),
            inputDir: inputFilePath.innerHTML,
            outputDir: outputFilePath.innerHTML,
            nGenerate: nOfAssetsInput.value
        }

        cfgsLoaded.push(newConfig);
        cfgs = JSON.stringify(cfgsLoaded);
        window.localStorage.setItem("savedConfigs", cfgs);
    }
}

function LoadData(parentElement){
    let cfgs = window.localStorage.getItem("savedConfigs");
    if(cfgs != undefined){
        let cfgsLoaded = JSON.parse(cfgs);
        let counter = 0;
        parentElement.innerHTML = "";
        if(cfgsLoaded.length == 0){
            parentElement.innerHTML = `<p>You currently have no saved configurations.</p>`;
        }
        else{
            Array.from(cfgsLoaded).forEach(saveData => {
                parentElement.innerHTML += 
                `
                <div class="load-element">
                    <div class="breadcrumbs">
                        <div class="bc-button bc-type"><div class="bc-icon-container"><svg class="bc-icon"><use xlink:href=".\\icons\\breadcrumb-item.svg#bc"/></svg></div><div class="bc-label">Output: ${saveData.type}</div></div>
                        <div class="bc-button bc-format"><div class="bc-icon-container"><svg class="bc-icon"><use xlink:href=".\\icons\\breadcrumb-item.svg#bc"/></svg></div><div class="bc-label">Format: ${saveData.format}</div></div>
                        <div class="bc-button bc-inputTech"><div class="bc-icon-container"><svg class="bc-icon"><use xlink:href=".\\icons\\breadcrumb-item.svg#bc"/></svg></div><div class="bc-label">Input: ${saveData.input}</br>Technique: ${saveData.tech}</div></div>
                    </div>
                    <div class="load-button-container">
                        <button class="progress-button del-button" id="del-button-${counter}"><p>Delete</p><svg><use xlink:href=".\\icons\\xmark-solid.svg#icon"/></svg></button>
                    </div>
                    <div class="load-button-container">
                        <button class="progress-button" id="prog-button-${counter}"><p>Load</p><svg><use xlink:href=".\\icons\\arrow-right-solid.svg#icon"/></svg></button>
                    </div>
                </div>
                `;

                counter++;
            });
        }   
        let makeLoadHandler = function(save){
            return function(){
                window.location.href='./page_4.html';
                window.sessionStorage.setItem("currentDataType", save.type);
                window.sessionStorage.setItem("currentDataFormat", save.format);
                window.sessionStorage.setItem("currentDataInput", save.input);
                window.sessionStorage.setItem("currentDataTech", save.tech);
                window.sessionStorage.setItem("dataTypeDimension", save.typeDim);
                window.sessionStorage.setItem("currentInputDir", save.inputDir);
                window.sessionStorage.setItem("currentOutputDir", save.outputDir);
                window.sessionStorage.setItem("currentNGen", save.nGenerate);
            };
        }

        let makeDeleteHandler = function(save){
            return function(){
                let index = cfgsLoaded.indexOf(save);
                if(index > -1){
                    cfgsLoaded.splice(index, 1);
                }
                cfgs = JSON.stringify(cfgsLoaded);
                window.localStorage.setItem("savedConfigs", cfgs);
                LoadData(parentElement);
            };
        }

        for(let i = 0; i < counter; i++){
            let progButton = document.getElementById(`prog-button-${i}`);
            let delButton = document.getElementById(`del-button-${i}`)
            progButton.onclick = makeLoadHandler(cfgsLoaded[i]);
            delButton.onclick = makeDeleteHandler(cfgsLoaded[i]);
        }
    }
}